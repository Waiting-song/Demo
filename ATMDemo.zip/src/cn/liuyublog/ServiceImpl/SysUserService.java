package cn.liuyublog.ServiceImpl;

import java.sql.SQLException;

import cn.liuyublog.Service.ISysUserService;
import cn.liuyublog.dao.TSysUserDao;
import cn.liuyublog.domain.TSysUser;

// ����ʵ�ֲ�
public class SysUserService implements ISysUserService {

	private TSysUserDao sysUserDao = new TSysUserDao();
	@Override
	public boolean registerUser(TSysUser user) throws ClassNotFoundException, SQLException {
		return sysUserDao.registerUser(user);
	}

	//修改密码
	@Override
	public boolean changePwd(TSysUser user) throws ClassNotFoundException, SQLException {
	return sysUserDao.changePwd(user);
	}

	@Override
	public TSysUser login(TSysUser user) throws ClassNotFoundException, SQLException {
		return sysUserDao.login(user);
	}

	@Override
	public boolean checkUserName(TSysUser user) throws ClassNotFoundException, SQLException {
	return sysUserDao.checkUserName(user);
	}

	@Override
	public void logout(TSysUser user) {
		// TODO Auto-generated method stub

	}

	@Override
	public String getAccountLeftCash(TSysUser user) throws ClassNotFoundException, SQLException {
		return sysUserDao.getAccountLeftCash(user);
		
	}

	@Override
	public boolean haveCashOrNot(TSysUser user,String getMoney) throws ClassNotFoundException, SQLException {
		int leftCash = Integer.valueOf(getAccountLeftCash(user));
		int getCash = Integer.valueOf(getMoney);
		if(getCash>leftCash)
		{
			return false;
		}
		return true;
	}

	@Override
	public TSysUser getUserByUserName(String userName) throws ClassNotFoundException, SQLException {
	  return sysUserDao.getUserByUserName(userName);
	}

}
