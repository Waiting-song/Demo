package cn.liuyublog.Servlet;

import cn.liuyublog.Service.ISysUserService;
import cn.liuyublog.ServiceImpl.SysUserService;
import cn.liuyublog.domain.TSysUser;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.UUID;


@WebServlet( "/registUser")
public class RegistServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        System.out.println("注册");
        request.setCharacterEncoding("UTF-8");
        ISysUserService userService = new SysUserService();
        TSysUser user = new TSysUser();
        user.setSysUserId(UUID.randomUUID().toString());
        user.setSysUserName(request.getParameter("userName"));
        user.setSysUserPwd(request.getParameter("password"));
        try {
            if (userService.registerUser(user)) {
                System.out.println("注册成功");
                response.sendRedirect(request.getContextPath()+"atmLogin.jsp");
            } else {
                System.out.println("注册失败");
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
