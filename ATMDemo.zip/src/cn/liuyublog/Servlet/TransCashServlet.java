package cn.liuyublog.Servlet;

import cn.liuyublog.Service.IAccountDetailService;
import cn.liuyublog.Service.ISysUserService;
import cn.liuyublog.ServiceImpl.AccountDetail;
import cn.liuyublog.ServiceImpl.SysUserService;
import cn.liuyublog.domain.TAccountDetail;
import cn.liuyublog.domain.TSysUser;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.UUID;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;



@WebServlet("/transCashURL")
public class TransCashServlet extends HttpServlet{

	private ISysUserService userService = new SysUserService();
	private IAccountDetailService detailService = new AccountDetail();
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		
		HttpSession session = request.getSession();
        TSysUser user = (TSysUser)session.getAttribute("myuser");
        
        String cash = request.getParameter("cashNum");
		// 转入方 id
        String transUserId = request.getParameter("transUserId");
        String result ="";
		try {
			// 检查当前账户余额是否充足
			if(userService.haveCashOrNot(user,cash))
			{
				// 果余额充足 可以转账
				TAccountDetail detail = new TAccountDetail();
				detail.setAccountId(UUID.randomUUID().toString());
				detail.setActionType("转出");
			    detail.setCash("-"+cash);
			    detail.setSysUserId(user.getSysUserId());
			    detail.setTransUserId(transUserId);
			    
			    // 如果转出成功
			    if(detailService.transfor(detail))
			    {
			    	// 开始转入
			    	TAccountDetail fdetail = new TAccountDetail();
					fdetail.setAccountId(UUID.randomUUID().toString());
					fdetail.setActionType("转入");
					fdetail.setSysUserId(transUserId);
					fdetail.setCash(cash);
					fdetail.setTransUserId("");
					fdetail.setFromUserId(user.getSysUserId());
					
					if(detailService.transfor(fdetail))
					{

						request.setAttribute("msg","转账成功");
					}
				else{
						request.setAttribute("msg","转账失败");
				}
			    	
			    }else{
					request.setAttribute("msg","账户转出失败");
			    }
				
			}else{
				request.setAttribute("msg","余额不足，不能转账");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} 

		request.getRequestDispatcher("/successful.jsp").forward(request,response);

		
		/*req.setAttribute("myresult", result);
		RequestDispatcher dis = req.getRequestDispatcher("/jsp/atm/result.jsp");
		dis.forward(req, resp);*/
		
	}

	
}
