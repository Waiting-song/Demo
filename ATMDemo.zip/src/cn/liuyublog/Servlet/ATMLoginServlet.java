package cn.liuyublog.Servlet;

import cn.liuyublog.Service.IAccountDetailService;
import cn.liuyublog.Service.ISysUserService;
import cn.liuyublog.ServiceImpl.AccountDetail;
import cn.liuyublog.ServiceImpl.SysUserService;
import cn.liuyublog.domain.TAccountDetail;
import cn.liuyublog.domain.TSysUser;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;



/**
 * Servlet implementation class HelloServlet
 */
@WebServlet("/atmLoginServlet")
public class ATMLoginServlet extends HttpServlet {

	private ISysUserService userService = new SysUserService();
	private IAccountDetailService detailService = new AccountDetail();
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		try {
			System.out.println("测试！");
			request.setCharacterEncoding("UTF-8");
			HttpSession session = request.getSession();
			TSysUser user = (TSysUser)session.getAttribute("myuser");
			String leftCash = userService.getAccountLeftCash(user);
			request.setAttribute("myLeftCash", leftCash);
			
			TAccountDetail detail = new TAccountDetail();
			detail.setSysUserId(user.getSysUserId());
			List detailList = detailService.getAccountDetail(detail);
			
			request.setAttribute("mydetailList", detailList);
			
			RequestDispatcher dispatcher = request.getRequestDispatcher("/main.jsp");
			dispatcher.forward(request, response);

			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		
			HttpSession session = request.getSession();
		try {
			String userName = request.getParameter("userName");
			String userPwd = request.getParameter("userPwd");
			
			TSysUser user = new TSysUser();
			user.setSysUserName(userName);
			user.setSysUserPwd(userPwd);
			
			TSysUser tempUser = userService.login(user);
			if(tempUser!=null)
			{
				session.setAttribute("myuser", tempUser);
				request.setAttribute("mymsg", "操作成功!");
			}else{
				request.setAttribute("mymsg", "操作失败!");
				response.sendRedirect("/atmLogin.jsp");
			}
			
			RequestDispatcher dispatcher = request.getRequestDispatcher("/mysuc.jsp");
			dispatcher.forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		} 
		
	
		
	
	}

}
