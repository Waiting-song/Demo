package cn.liuyublog.Servlet;

import cn.liuyublog.Service.ISysUserService;
import cn.liuyublog.ServiceImpl.SysUserService;
import cn.liuyublog.domain.TSysUser;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;



@WebServlet(name = "/changepwd",urlPatterns={"/changePwd"})
public class ChangePwdServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        ISysUserService userservice = new SysUserService();
        TSysUser user = new TSysUser();
        user.setSysUserName(request.getParameter("userName"));
        user.setSysUserPwd(request.getParameter("userPwd"));
        try {
            if (userservice.changePwd(user)) {
                request.setAttribute("msg","修改成功");
                response.sendRedirect(request.getContextPath()+"atmLogin.jsp");
            } else {
                request.setAttribute("msg","修改失败");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        request.getRequestDispatcher(request.getContextPath()+"/successful.jsp").forward(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }
}
