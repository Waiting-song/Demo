package cn.liuyublog.Servlet;

import cn.liuyublog.Service.ISysUserService;
import cn.liuyublog.ServiceImpl.SysUserService;
import cn.liuyublog.dao.AccountDetailDao;
import cn.liuyublog.domain.TAccountDetail;
import cn.liuyublog.domain.TSysUser;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.UUID;


@WebServlet("/saveMoney")
public class saveMoneyServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        System.out.println("存钱成功");
        AccountDetailDao detailDao = new AccountDetailDao();
        ISysUserService userService = new SysUserService();
        String userName = request.getParameter("userName");
        String saveMoney = request.getParameter("saveMoney");
        TSysUser sysUser=null;
        try {
            sysUser = userService.getUserByUserName(userName);
        } catch (Exception e) {
            e.printStackTrace();
        }
        String fromId = sysUser.getSysUserId();

        String leftMoney = null;
        try {
            leftMoney = userService.getAccountLeftCash(sysUser);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        if (leftMoney==null){
            leftMoney="0";
        }
        System.out.println("用户当前余额:" + leftMoney);



        TAccountDetail detail = new TAccountDetail();
        detail.setAccountId(UUID.randomUUID().toString());
        detail.setActionType("存钱");
        detail.setSysUserId(fromId);
        detail.setCash(saveMoney);
        detail.setTransUserId("");
        detail.setFromUserId("");
        try {
            String accountId = detailDao.insertDetail(detail);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        try {
            if (detailDao.updateDetail(detail)) {
                System.out.println("存钱成功!");
//                request.getRequestDispatcher("atmLoginServlet").forward(request,response);
                response.sendRedirect(request.getContextPath()+"/atmLoginServlet");
            } else {
                System.out.println("存钱失败!");
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        try {
            leftMoney = userService.getAccountLeftCash(sysUser);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
      /*  System.out.println("存入后的余额:" + leftMoney);
        showMessage(saveMoney, sysUser, name);*/

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
