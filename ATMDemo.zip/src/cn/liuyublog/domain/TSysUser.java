package cn.liuyublog.domain;

public class TSysUser {
	private String sysUserId;
	private String sysUserName;
	private String sysUserPwd;
	public String getSysUserId() {
		return sysUserId;
	}
	public void setSysUserId(String sysUserId) {
		this.sysUserId = sysUserId;
	}
	public String getSysUserName() {
		return sysUserName;
	}
	public void setSysUserName(String sysUserName) {
		this.sysUserName = sysUserName;
	}
	public String getSysUserPwd() {
		return sysUserPwd;
	}
	public void setSysUserPwd(String sysUserPwd) {
		this.sysUserPwd = sysUserPwd;
	}
	
	
}
