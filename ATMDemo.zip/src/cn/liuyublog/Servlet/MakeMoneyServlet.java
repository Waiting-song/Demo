package cn.liuyublog.Servlet;

import cn.liuyublog.Service.ISysUserService;
import cn.liuyublog.ServiceImpl.SysUserService;
import cn.liuyublog.dao.AccountDetailDao;
import cn.liuyublog.domain.TAccountDetail;
import cn.liuyublog.domain.TSysUser;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;
import java.util.UUID;


@WebServlet("/makeMoney")
public class MakeMoneyServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        System.out.println("取钱成功了； ~~~");
        TSysUser user = new TSysUser();
         AccountDetailDao detailDao = new AccountDetailDao();
        ISysUserService userService = new SysUserService();
        String userName = request.getParameter("userName");
        System.out.println(userName);
        String makeMoney = request.getParameter("makeMoney");
        //通过用户名获取一个对象
        try {
            TSysUser sysUser = userService.getUserByUserName(userName);

            String fromId = sysUser.getSysUserId();
            System.out.println(fromId);
            TAccountDetail detail = new TAccountDetail();
            detail.setAccountId(UUID.randomUUID().toString());
            detail.setActionType("取钱");
            detail.setSysUserId(fromId);
            detail.setCash("-" + makeMoney);
            detail.setTransUserId("");
            detail.setFromUserId("");


            user.setSysUserId(fromId);
            if (userService.haveCashOrNot(user, detail.getCash())) {
                String accountId = detailDao.insertDetail(detail);
                detail.setAccountId(accountId);
                if (detailDao.updateDetail(detail)) {
                    System.out.println("取钱成功！");
//                    request.getRequestDispatcher("atmLoginServlet").forward(request,response);
                    response.sendRedirect(request.getContextPath()+"/atmLoginServlet");
                } else {
                    System.out.println("取钱失败！");
                }
            } else {
                System.out.println("余额不足！");
            }


            System.out.println("当前余额:" + userService.getAccountLeftCash(user));

        } catch (Exception e) {
            e.printStackTrace();
        }

      /*  System.out.println("当前余额:" + userService.getAccountLeftCash(user));*/
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
