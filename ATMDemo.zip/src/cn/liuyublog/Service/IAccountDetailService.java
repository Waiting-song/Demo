package cn.liuyublog.Service;

import java.sql.SQLException;
import java.util.List;

import cn.liuyublog.domain.TAccountDetail;

public interface IAccountDetailService {
	//存钱
	public boolean deposit(TAccountDetail detail) throws ClassNotFoundException, SQLException;
	// 取钱
	public boolean getCash(TAccountDetail detail) throws ClassNotFoundException, SQLException;
    //转账
	public boolean transfor(TAccountDetail detail) throws ClassNotFoundException, SQLException;
	
	public List getAccountDetail(TAccountDetail detail) throws ClassNotFoundException, SQLException;
	
}
